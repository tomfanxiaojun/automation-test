package cn.epam.cdp.cnta2015.module3.lecture1.demo;

public class Calculation {

	private int value;
	
	public Calculation(int value) {
		this.value = value;
	}
	
	public int sum() {
		int result = 0;
		for(int i=0; i<=this.value; i++){
			result += i;
		}
		return result;
	}
	
	public int factorial() {
		int result = 1;
		for(int i=1; i<=this.value; i++){
			result *= i;
		}
		return result;
		
	}
	
}
