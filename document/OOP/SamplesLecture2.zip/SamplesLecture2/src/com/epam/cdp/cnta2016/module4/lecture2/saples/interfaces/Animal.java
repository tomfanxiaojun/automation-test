package com.epam.cdp.cnta2016.module4.lecture2.saples.interfaces;

public interface Animal {
	public void eat();
	public void travel();
	
}
