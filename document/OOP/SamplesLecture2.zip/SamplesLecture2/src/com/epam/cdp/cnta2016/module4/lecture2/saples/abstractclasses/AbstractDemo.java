package com.epam.cdp.cnta2016.module4.lecture2.saples.abstractclasses;

public abstract class AbstractDemo {

	public void method1() {
		System.out.println("Concrete method of abstract class");
	}

	abstract public void method2();

}