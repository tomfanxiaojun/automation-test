package Javahomework2.cn.epam.javahometask2;

public class Bouquet {
	
	String name;
	int totalprice =0;
	
	
	
	public Bouquet(String name){
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	

	
	
}
