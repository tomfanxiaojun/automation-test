package com.epam.ta.oop.ivan;

public enum ColorType {
	RED("red"), BLUE("blue"), YELLOW("yellow"), BLACK("black");
	private String colorName;

	ColorType(String colorName) {
		this.colorName = colorName;
	}

	@Override
	public String toString() {
		return colorName;
	}
}
