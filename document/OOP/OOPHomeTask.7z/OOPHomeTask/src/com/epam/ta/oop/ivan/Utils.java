package com.epam.ta.oop.ivan;

import java.util.Scanner;


public class Utils {

	public static Boolean isDouble(String value){
		try{
			Double.parseDouble(value);
			return true;
		}catch(Exception e){
			return false;
		}
		
	}
	public static Boolean isInt(String value){
		try{
			Integer.parseInt(value);
			return true;
		}catch(Exception e){
			return false;
		}
		
	}
	public static Boolean isGreaterThanZero(int number){
		return number>0?true:false;
	}
	public static int inputNumber(String inputName){
		Scanner scanner = new Scanner(System.in);
		String inputString = scanner.next();			
		while(!Utils.isInt(inputString)||!Utils.isGreaterThanZero(Integer.parseInt(inputString))){
			System.out.println("Please, enter a correct number for '"+inputName+"':");
			inputString = scanner.next();
		}
		return Integer.parseInt(inputString);
	}
}
