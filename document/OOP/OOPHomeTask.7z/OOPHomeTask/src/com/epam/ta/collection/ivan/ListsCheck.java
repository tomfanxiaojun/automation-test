package com.epam.ta.collection.ivan;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.Random;

public class ListsCheck {
	// check ArrayList and LinkedList
	public static void main(String[] args) {
		int listSize = 100000;
		System.out.println("******************Add********************");
		ArrayList<String> arrayList = new ArrayList<String>();
		long startDate = new Date().getTime();
		for (int i = 1; i <= listSize; i++) {
			arrayList.add("arrayList-" + i);
		}
		long endDate = new Date().getTime();
		long arrayListAddTimeGap = endDate - startDate;
		System.out.println("Array list add elements time gap is :"
				+ arrayListAddTimeGap);

		LinkedList<String> linkedList = new LinkedList<String>();
		startDate = new Date().getTime();
		for (int i = 1; i <= listSize; i++) {
			linkedList.add("linkedList-" + i);
		}
		endDate = new Date().getTime();
		long linkedListAddTimeGap = endDate - startDate;
		System.out.println("Linked list add elements time gap is :"
				+ linkedListAddTimeGap);
		System.out.println("Add elements,the time gap is :"
				+ (linkedListAddTimeGap - arrayListAddTimeGap));
		System.out.println("******************Get********************");
		int getSize = listSize/10;
		Random random = new Random();
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			String arr01 = arrayList.get(index);
		}
		endDate = new Date().getTime();
		long arrayListGetTimeGap = endDate - startDate;
		System.out.println("Array list get elements by index time gap is :"
				+ arrayListGetTimeGap);
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			String arr01 = linkedList.get(index);
		}
		endDate = new Date().getTime();
		long linkedListGetTimeGap = endDate - startDate;
		System.out.println("Linked list get elements by index time gap is :"
				+ linkedListGetTimeGap);
		System.out.println("Get elements,the time gap is :"
				+ (linkedListGetTimeGap - arrayListGetTimeGap));
		System.out.println("******************Insert********************");
		int insertIndex = listSize/10;
		int insertSize=100000;
		
		startDate = new Date().getTime();
		for(int i=1;i<=insertSize;i++){
			arrayList.add(insertIndex+i, "arrayList-insert-");
		}
		endDate = new Date().getTime();
		long arrayListInsertTimeGap = endDate - startDate;
		System.out.println("Array list insert elements by index time gap is :"
				+ arrayListInsertTimeGap);
		startDate = new Date().getTime();
		for(int i=1;i<=insertSize;i++){
			linkedList.add(insertIndex+i, "linkedList-insert-");
		}
		endDate = new Date().getTime();
		long linkedListInsertTimeGap = endDate - startDate;
		System.out.println("Linked list insert elements by index time gap is :"
				+ linkedListInsertTimeGap);
		System.out.println("Insert elements,the time gap is :"
				+ (linkedListInsertTimeGap - arrayListInsertTimeGap));
		System.out.println("******************Remove********************");
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			 arrayList.remove(index);
		}
		endDate = new Date().getTime();
		long arrayListRemoveTimeGap = endDate - startDate;
		System.out.println("Array list remove elements by index time gap is :"
				+ arrayListRemoveTimeGap);
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			linkedList.remove(index);
		}
		endDate = new Date().getTime();
		long linkedListRemoveTimeGap = endDate - startDate;
		System.out.println("Linked list remove elements by index time gap is :"
				+ linkedListRemoveTimeGap);
		System.out.println("Remove elements,the time gap is :"
				+ (linkedListRemoveTimeGap - arrayListRemoveTimeGap));
	}
}
