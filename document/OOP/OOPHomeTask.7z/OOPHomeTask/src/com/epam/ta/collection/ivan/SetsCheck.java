package com.epam.ta.collection.ivan;

import java.util.Date;
import java.util.HashSet;
import java.util.Random;
import java.util.TreeSet;

public class SetsCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int listSize = 10000000;
		System.out.println("******************Add********************");
		HashSet<String> hashSet = new HashSet<String>();
		long startDate = new Date().getTime();
		for (int i = 1; i <= listSize; i++) {
			hashSet.add("hashSet-" + i);
		}
		long endDate = new Date().getTime();
		long hashSetAddTimeGap = endDate - startDate;
		System.out.println("Hash set add elements time gap is :"
				+ hashSetAddTimeGap);
		TreeSet<String> treeSet = new TreeSet<String>();
		startDate = new Date().getTime();
		for (int i = 1; i <= listSize; i++) {
			treeSet.add("treeSet-" + i);
		}
		endDate = new Date().getTime();
		long treeSetAddTimeGap = endDate - startDate;
		System.out.println("Tree set add elements time gap is :"
				+ treeSetAddTimeGap);
		System.out.println("Add elements,the time gap is :"
				+ (treeSetAddTimeGap - hashSetAddTimeGap));
		System.out.println("******************Remove********************");
		int removeSize = listSize / 10;
		Random random = new Random();
		startDate = new Date().getTime();
		for (int i = 1; i <= removeSize; i++) {
			int index = random.nextInt(listSize - 1);
			hashSet.remove("hashSet-" + index);
		}
		endDate = new Date().getTime();
		long hashSetRemoveTimeGap = endDate - startDate;
		System.out.println("hash set remove elements by index time gap is :"
				+ hashSetRemoveTimeGap);
		startDate = new Date().getTime();
		for (int i = 1; i <= removeSize; i++) {
			int index = random.nextInt(listSize - 1);
			treeSet.remove("treeSet-" + index);
		}
		endDate = new Date().getTime();
		long treeSetRemoveTimeGap = endDate - startDate;
		System.out.println("hash set remove elements by index time gap is :"
				+ treeSetRemoveTimeGap);
		System.out.println("Remove elements,the time gap is :"
				+ (treeSetRemoveTimeGap - hashSetRemoveTimeGap));
		System.out.println("******************Conclusion********************");
		System.out
				.println("1,The main difference of set with list is that all elements cann't repeat for set. ");
		System.out
				.println("2,hashSet cann't guarantees  the order of iteration");
		System.out.println("3,hashSet is not thread safty");
		System.out.println("4,treeSet is substantially slower than hashSet");
	}

}
