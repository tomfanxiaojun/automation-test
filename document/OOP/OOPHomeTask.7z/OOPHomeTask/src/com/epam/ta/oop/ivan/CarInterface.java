package com.epam.ta.oop.ivan;

public interface CarInterface {
	// get the car base info
public void getCarBaseInfo();

public int getCapacity();
}
