package com.epam.ta.oop.ivan; 
import java.util.Comparator;
public class FuelConsumptionComparator implements Comparator<Car> {
	public int compare(Car o1, Car o2) {
		return (o2.getCarType().getFuelConsumptionValue() - o1.getCarType().getFuelConsumptionValue())>0?1:-1;
	}
}
