package com.epam.ta.oop.ivan;

import java.util.Date;

public abstract class Company {
	private String companyNumber;
	private String companyName;
	private String companyAddress;
	private Date registrationDate;
	public Company(String companyNumber,String companyName,String companyAddress,Date registrationDate){
		this.companyNumber=companyNumber;
		this.companyName=companyName;
		this.companyAddress=companyAddress;
		this.registrationDate=registrationDate;
	}
	public String toString(){
		StringBuilder info=new StringBuilder();
		info.append("My compamy number is "+this.companyNumber+"\n");
		info.append("My compamy name is "+this.companyName+"\n");
		info.append("My compamy address is "+this.companyAddress+"\n");
		info.append("My registration date is "+this.registrationDate+"\n");
		return info.toString();
	}
	abstract public void getCompanyType();
	public String getCompanyNumber() {
		return companyNumber;
	}
	public void setCompanyNumber(String companyNumber) {
		this.companyNumber = companyNumber;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyAddress() {
		return companyAddress;
	}
	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	
}
