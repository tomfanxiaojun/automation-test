package com.epam.ta.oop.ivan;

public class Car implements CarInterface {

	private String carNumber;
	private CarType carType;
	private ColorType colorType;
	private double speed;
	
	public Car(String carNumber,CarType carType,ColorType colorType,double speed){
		this.carNumber=carNumber;
		this.carType=carType;
		this.colorType=colorType;
		this.speed=speed;
	}
	@Override
	public void getCarBaseInfo() {
		System.out.println("My car number is "+this.carNumber);
		System.out.println("I am a "+this.carType.getCarName());
		System.out.println("My color is  "+this.colorType.toString());
		System.out.println("I have  "+this.carType.getSeatSize()+" seats");
		System.out.println("My speed is   "+this.speed);
		System.out.println("I will consume   "+this.carType.getFuelConsumptionValue()+" fuel per km");
		System.out.println("**********************end*******************");
	}

	@Override
	public int getCapacity() {		 
		return this.carType.getSeatSize();
	}

	public String getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(String carNumber) {
		this.carNumber = carNumber;
	}

	public CarType getCarType() {
		return carType;
	}

	public void setCarType(CarType carType) {
		this.carType = carType;
	}

	public ColorType getColorType() {
		return colorType;
	}

	public void setColorType(ColorType colorType) {
		this.colorType = colorType;
	}

	public double getSpeed() {
		return speed;
	}

}
