package com.epam.ta.collection.ivan;

import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import java.util.TreeMap;

public class MapsCheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int listSize = 10000000;
		System.out.println("******************Add********************");
		HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
		long startDate = new Date().getTime();
		for (int i = 1; i <= listSize; i++) {
			hashMap.put("hashMap-" + i, i);
		}
		long endDate = new Date().getTime();
		long hashMapAddTimeGap = endDate - startDate;
		System.out.println("Hash map add elements time gap is :"
				+ hashMapAddTimeGap);
		TreeMap<String, Integer> treeMap = new TreeMap<String, Integer>();
		startDate = new Date().getTime();
		for (int i = 1; i <= listSize; i++) {
			treeMap.put("treeMap-" + i, i);
		}
		endDate = new Date().getTime();
		long treeMapAddTimeGap = endDate - startDate;
		System.out.println("Tree mpa add elements time gap is :"
				+ treeMapAddTimeGap);
		System.out.println("Add elements,the time gap is :"
				+ (treeMapAddTimeGap - hashMapAddTimeGap));
		System.out.println("******************Get********************");
		int getSize = listSize / 10;
		Random random = new Random();
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			int value = hashMap.get("hashMap-" + index);
		}
		endDate = new Date().getTime();
		long hashMapGetTimeGap = endDate - startDate;
		System.out.println("Hash map get elements by index time gap is :"
				+ hashMapGetTimeGap);

		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			int value = treeMap.get("treeMap-" + index);
		}
		endDate = new Date().getTime();
		long treeMapGetTimeGap = endDate - startDate;
		System.out.println("Tree map get elements by index time gap is :"
				+ treeMapGetTimeGap);
		System.out.println("Get elements,the time gap is :"
				+ (treeMapGetTimeGap - hashMapGetTimeGap));

		System.out.println("******************Remove********************");
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			hashMap.remove("hashMap-" + index);
		}
		endDate = new Date().getTime();
		long hashMapRemoveTimeGap = endDate - startDate;
		System.out.println(" Hash map remove elements by index time gap is :"
				+ hashMapRemoveTimeGap);
		startDate = new Date().getTime();
		for (int i = 0; i < getSize; i++) {
			int index = random.nextInt(listSize - 1);
			treeMap.remove("treeMap-" + index);
		}
		endDate = new Date().getTime();
		long treeMapRemoveTimeGap = endDate - startDate;
		System.out.println(" Tree map remove elements by index time gap is :"
				+ treeMapRemoveTimeGap);
		System.out.println("Remove elements,the time gap is :"
				+ (treeMapRemoveTimeGap - hashMapRemoveTimeGap));

		System.out.println("******************Conclusion********************");
		System.out.println("1,Map is key to value collection. ");
		System.out.println("2,hashMap cann't guarantees  the order of iteration . ");
	}

}
