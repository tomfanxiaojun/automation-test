package com.epam.ta.oop.ivan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Random;

public class OOPRunner {

	public static void main(String[] args) {
		// set cars
		ArrayList<Car> cars = new ArrayList<Car>();
		Random random = new Random();
		for (int i = 1; i <= 5; i++) {
			Car car = new Car("car-" + i, CarType.CAR, getRandomCarColor(i),
					(int) (random.nextDouble() * 10000 / 100));
			// car.getCarBaseInfo();
			cars.add(car);
		}
		for (int i = 1; i <= 4; i++) {
			Car car = new Car("min-bus-" + i, CarType.MIN_BUS,
					getRandomCarColor(i),
					(int) (random.nextDouble() * 10000 / 100));
			// car.getCarBaseInfo();
			cars.add(car);
		}
		for (int i = 1; i <= 7; i++) {
			Car car = new Car("big-bus-" + i, CarType.BIG_BUS,
					getRandomCarColor(i),
					(int) (random.nextDouble() * 10000 / 100));
			// car.getCarBaseInfo();
			cars.add(car);
		}
		for (int i = 1; i <= 6; i++) {
			Car car = new Car("truck-" + i, CarType.TRUCK,
					getRandomCarColor(i),
					(int) (random.nextDouble() * 10000 / 100));
			// car.getCarBaseInfo();
			cars.add(car);
		}
		// set car company
		System.out
				.println("=============get company base info====================");
		CarCompany carCompany = new CarCompany("0001", "BMW", "China",
				new Date(), cars);
		//carCompany.getCompanyType();
		// get the amount of the
		int seats = carCompany.getAllSeats();
		System.out.println("The amount of passengers seats is " + seats);
		//System.out.println(carCompany.toString());
		System.out
				.println("============find a car by range of parameters.=====================");
		try {
			System.out.println("Please input you want to order the seats number:");
			int seatNumber=Utils.inputNumber("seat number");
			ArrayList<Car> returnCars = carCompany.findCarsByPeoples(seatNumber);
			System.out.println("Hi ,customer,");
			System.out
					.println("We will arrange the car to you ,base info is as follow:");
			for (int i = 0; i < returnCars.size(); i++) {
				returnCars.get(i).getCarBaseInfo();
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		System.out
				.println("==============sort by fuel consumption===================");
		// Sort the car park by fuel consumption desc
		Collections.sort(cars, new FuelConsumptionComparator());
		for (int i = 0; i < cars.size(); i++) {
			cars.get(i).getCarBaseInfo();
		}
	}

	public static ColorType getRandomCarColor(int index) {
		int value = index % 4;
		switch (value) {
		case 1:
			return ColorType.RED;
		case 2:
			return ColorType.BLUE;
		case 3:
			return ColorType.YELLOW;
		case 4:
			return ColorType.BLACK;
		default:
			return ColorType.BLACK;
		}
	}

}
