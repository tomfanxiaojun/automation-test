package com.epam.ta.oop.ivan;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class CarCompany extends Company {
	private ArrayList<Car> cars;
	HashMap<CarType, ArrayList<Car>> carsMap = new HashMap<CarType, ArrayList<Car>>();

	public CarCompany(String companyNumber, String companyName,
			String companyAddress, Date registrationDate, ArrayList<Car> cars) {
		super(companyNumber, companyName, companyAddress, registrationDate);
		for (int i = 0; i < cars.size(); i++) {
			if (carsMap.containsKey(cars.get(i).getCarType())) {
				ArrayList<Car> tempCars = carsMap.get(cars.get(i).getCarType());
				tempCars.add(cars.get(i));
				carsMap.put(cars.get(i).getCarType(), tempCars);
			} else {
				ArrayList<Car> tempCars = new ArrayList<Car>();
				tempCars.add(cars.get(i));
				carsMap.put(cars.get(i).getCarType(), tempCars);
			}
		}
		this.cars = cars;
	}

	@Override
	public void getCompanyType() {
		System.out.println("I am a car company.");

	}

	public int getAllSeats() {
		int seats = 0;
		for (int i = 0; i < cars.size(); i++) {
			seats = seats + cars.get(i).getCapacity();
		}
		return seats;
	}

	public ArrayList<Car> findCarsByPeoples(int peoples) throws Exception {
		if (peoples < 1) {
			throw new Exception("The peoples number must be greater than 0");
		}
		if (peoples > this.getAllSeats()) {
			throw new Exception("Our company only " + this.getAllSeats()
					+ " seats,so not have enough seats for you.");
		}		
		ArrayList<Car> resultCars = new ArrayList<Car>();
		if (peoples <= 4 && carsMap.get(CarType.CAR).size() > 0) {
			resultCars.add(carsMap.get(CarType.CAR).get(0));
			ArrayList<Car> tempList = carsMap.get(CarType.CAR);
			tempList.remove(0);
			carsMap.put(CarType.CAR, tempList);
			return resultCars;
		}
		if (peoples <= 16 && carsMap.get(CarType.MIN_BUS).size() > 0) {
			resultCars.add(carsMap.get(CarType.MIN_BUS).get(0));
			ArrayList<Car> tempList = carsMap.get(CarType.MIN_BUS);
			tempList.remove(0);
			carsMap.put(CarType.MIN_BUS, tempList);
			return resultCars;
		}
		if (peoples <= 42 && carsMap.get(CarType.BIG_BUS).size() > 0) {
			resultCars.add(carsMap.get(CarType.BIG_BUS).get(0));
			ArrayList<Car> tempList = carsMap.get(CarType.MIN_BUS);
			tempList.remove(0);
			carsMap.put(CarType.BIG_BUS, tempList);
			return resultCars;
		}
		if (peoples <= 120 && carsMap.get(CarType.TRUCK).size() > 0) {
			resultCars.add(carsMap.get(CarType.TRUCK).get(0));
			ArrayList<Car> tempList = carsMap.get(CarType.TRUCK);
			tempList.remove(0);
			carsMap.put(CarType.TRUCK, tempList);
			return resultCars;
		} else {
			int trucks = peoples / 120;
			int remains = peoples % 120;
			if (trucks > carsMap.get(CarType.TRUCK).size()) {
				remains = remains
						+ (trucks - carsMap.get(CarType.TRUCK).size()) * 120;
				trucks = carsMap.get(CarType.TRUCK).size();
			}
			ArrayList<Car> trackTemp = carsMap.get(CarType.TRUCK);
			for (int i = trucks - 1; i >= 0; i--) {
				resultCars.add(trackTemp.get(i));
				trackTemp.remove(i);
			}
			carsMap.put(CarType.TRUCK, trackTemp);

			resultCars.addAll(findCarsByPeoples(remains));
			return resultCars;
		}

	}

	// private getCarsListByCarTypeAndSea
	public ArrayList<Car> getCars() {
		return cars;
	}

	public void setCars(ArrayList<Car> cars) {
		this.cars = cars;
	}
}
