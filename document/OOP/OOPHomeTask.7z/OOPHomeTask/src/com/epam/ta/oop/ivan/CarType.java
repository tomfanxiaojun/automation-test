package com.epam.ta.oop.ivan;

/*car type
 * */
public enum CarType {
	CAR("car",FuelConsumptionType.LOW, 4), MIN_BUS("min bus",FuelConsumptionType.LOW, 16), BIG_BUS("big bus",
			FuelConsumptionType.MIDDLE, 42), TRUCK("bruck",FuelConsumptionType.HIGHT,
			120);

	private final double fuelConsumptionValue;
    private final int seatSize;
    private final String carName;
	CarType(String carName,FuelConsumptionType fuelConsumptionType, int seatSize) {
		this.carName=carName;
		this.seatSize=seatSize;
		this.fuelConsumptionValue = fuelConsumptionType.consumptionValue()
				* seatSize;
	}

	public double getFuelConsumptionValue() {
		return this.fuelConsumptionValue;
	}
	public int getSeatSize(){
		return this.seatSize;
	}
    public String getCarName(){
    	return this.carName;
    }
	/* fuel consumption type */
	private enum FuelConsumptionType {
		LOW(0.8), MIDDLE(1.2), HIGHT(1.8);
		// consume base line
		private static final int BASE_CONSUMPTION_LINE = 5;
		private final double fuelConsumptionRate;

		FuelConsumptionType(double fuelConsumptionRate) {
			this.fuelConsumptionRate = fuelConsumptionRate;
		}

		private double consumptionValue() {
			return this.fuelConsumptionRate * this.BASE_CONSUMPTION_LINE;
		};
	}
}
