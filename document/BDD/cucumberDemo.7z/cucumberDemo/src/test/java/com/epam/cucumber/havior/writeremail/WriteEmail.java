package com.epam.cucumber.havior.writeremail;

import com.epam.cucumber.basehavior.BaseBehavior;

import cucumber.api.java.en.When;

public class WriteEmail   extends BaseBehavior {
	@When("^click wirte email button$")
	public void clickWriteEmailButton() throws Throwable {		 
		tester.clickWriteEmailButton();
	}
}
