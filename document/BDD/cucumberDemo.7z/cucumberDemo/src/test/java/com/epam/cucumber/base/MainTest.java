package com.epam.cucumber.base;

import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
 


import com.epam.cucumber.core.Driver;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources" }, format = { "pretty",
		"html:target/reports/cucumber/html", "json:target/cucumber.json",
		"usage:target/usage.jsonx", "junit:target/junit.xml" }, tags = { "@start" }, glue = { "com.epam.cucumber" })
public class MainTest {

	@Before
	public static void setUp() {
		Driver.getInstance();
	}

	@After
	public static void tearDown() throws IOException {
		Driver.getInstance().quit();
	}
}