package com.epam.cucumber.havior.login;

import static junit.framework.Assert.assertTrue;

import com.epam.cucumber.pages.EmailHomePage;
import com.epam.cucumber.pages.LoginPage;

 

public class LoginAssert extends LoginPage {
    public void checkThatTestManagemantPageOpened(LoginPage loginPage) {
        assertTrue(loginPage.progreessbar.isDisplayed());
    }
}
