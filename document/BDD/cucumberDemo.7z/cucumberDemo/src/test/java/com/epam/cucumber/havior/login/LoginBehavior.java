package com.epam.cucumber.havior.login;
 

import com.epam.cucumber.Objects.UserModel;
import com.epam.cucumber.basehavior.BaseBehavior;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginBehavior extends BaseBehavior {

	private LoginAssert loginAssert = new LoginAssert();

	@Given("^tester wants to login$")
	public void tester_wants_to_login() throws Throwable {
		tester.atLoginPage().open();
	}

	@When("^tester provides email and password - ([^\\\"]*) and ([^\\\"]*)$")
	public void tester_provides_correct_credentials(String email, String password) throws Throwable {
		UserModel userModel=new UserModel();
		userModel.setEmail(email);
		userModel.setPassWord(password);
		tester.login(userModel);
	}

	@Then("^tester should see the write email button$")
	public void tester_should_see_Test_Management_plugin_welcome_page() throws Throwable {
		loginAssert.checkThatTestManagemantPageOpened(tester.atLoginPage());
		tester.logout();
	}

	@Then("^tester should see error message - ([^\\\"]*)$")
	public void tester_should_see_login_page(String errorMessage) throws Throwable {
		//loginAssert.checkErrorMessageOnLoginPage(errorMessage);
//		tester.logout();
	}
}
