package com.epam.cucumber.basehavior;

import com.epam.cucumber.steps.Tester;

 

public class BaseBehavior {
	 protected Tester tester = new Tester();
}
