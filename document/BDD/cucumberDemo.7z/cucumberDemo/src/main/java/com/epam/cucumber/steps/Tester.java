package com.epam.cucumber.steps;

import org.openqa.selenium.support.PageFactory;

import com.epam.cucumber.Objects.UserModel;
import com.epam.cucumber.core.Driver;
import com.epam.cucumber.pages.*;
 

public class Tester {
	private LoginPage loginPage = PageFactory.initElements(
			Driver.getInstance(), LoginPage.class);
 
	private EmailHomePage emailHomePage = PageFactory.initElements(Driver.getInstance(),
			EmailHomePage.class);
	public LoginPage atLoginPage() {
		if (loginPage == null) {
			loginPage = PageFactory.initElements(Driver.getInstance(),
					LoginPage.class);
		}
		return loginPage;
	}

 
	public EmailHomePage atEmailHomePage() {
		if (emailHomePage == null) {
			emailHomePage = PageFactory.initElements(Driver.getInstance(),
					EmailHomePage.class);
		}
		return emailHomePage;
	}
	public void login(UserModel userModel)
			throws InterruptedException {
		atLoginPage().open();
		Thread.sleep(1000);
		if (atLoginPage().isElementPresent(atLoginPage().loginEmailInput)) {
			atLoginPage().login(userModel);
			Thread.sleep(1000*5);
		 
			 
		}
	 
	}
	public void clickWriteEmailButton() {
		if (atEmailHomePage().isElementPresent(atEmailHomePage().writeEmailButton)) {
			atEmailHomePage().clickWriteEmailBt();
			 
		}
	 
	}
	public void logout() {
//		atLoginPage().clickOnAvatar();
//		atLoginPage().clickOnLogOutButton();
	}

}
