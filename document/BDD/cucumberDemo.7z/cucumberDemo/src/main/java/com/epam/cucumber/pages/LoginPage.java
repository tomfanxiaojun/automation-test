package com.epam.cucumber.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

 
import com.epam.cucumber.Objects.UserModel;
 
 

public class LoginPage extends BasePage {
	private final static Logger logger = Logger.getLogger(LoginPage.class);
	//login
	@FindBy(id = "Email")
	public WebElement loginEmailInput; 
	@FindBy(id = "next")
	public WebElement loginNextButton;
	@FindBy(id = "Passwd")
	public WebElement loginPasswdInput;
	@FindBy(id = "signIn")
	public WebElement loginButton;
	@FindBy(xpath = "//div[@class='msg']")
	public WebElement progreessbar;
	 
	private static final String START_URL = "https://accounts.google.com/ServiceLogin?sacu=1&scc=1&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&osid=1&service=mail&ss=1&ltmpl=default&rm=false&lp=1&hl=en#password";
	public void open() {
		getDriver().get(START_URL);
	}
	public  void login(UserModel userModel) {	 
		logger.info("Typing user login email: " + userModel.getEmail());
		loginEmailInput.clear();
		loginEmailInput.sendKeys(userModel.getEmail());
		loginNextButton.click();;
		loginPasswdInput.clear();
		logger.debug("Typing user password: " + userModel.getPassWord());
		loginPasswdInput.sendKeys(userModel.getPassWord());
		loginButton.click();
		logger.debug("Login is in progress...");
		
	}

}
