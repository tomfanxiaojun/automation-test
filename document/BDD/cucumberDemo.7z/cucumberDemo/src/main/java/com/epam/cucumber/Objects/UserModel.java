package com.epam.cucumber.Objects;

public class UserModel {
private String email;
private String passWord;
public UserModel(){
	
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassWord() {
	return passWord;
}
public void setPassWord(String passWord) {
	this.passWord = passWord;
}
}
