package com.epam.cucumber.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.epam.cucumber.Objects.UserModel;

public class EmailHomePage extends BasePage {
	@FindBy(xpath = "//div[@role='button'][@tabindex='0'][@gh='cm']")
	public WebElement writeEmailButton;
	
	@FindBy(xpath = "//a[@href='https://mail.google.com/mail/u/0/#drafts']")
	public WebElement draftLink;
	@FindBy(xpath = "//a[@href='https://mail.google.com/mail/u/0/#sent']")
	public WebElement sendLink;
	@FindBy(xpath = "//span[@class='gb_1a gbii']")
	public WebElement logoutLink;
	@FindBy(xpath = "//a[contains(@href, 'Logout')]")
	public WebElement logoutButton;
	@FindBy(xpath = "//a[contains(@aria-label, 'Settings')]")
	public WebElement settingButton;
	
	public  void clickWriteEmailBt() {	 
		writeEmailButton.click();		
	}
}
