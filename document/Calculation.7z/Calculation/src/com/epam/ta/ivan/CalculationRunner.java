package com.epam.ta.ivan;

import java.util.Scanner;
/*
 * CalculationRunner
 * author:Ivan_Fan@epam.com
 * 2015-12-30
 * */
public class CalculationRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean isRepeat = true;
		while (isRepeat) {			
			System.out.println("1 - addition");
			System.out.println("2 - substraction");
			System.out.println("3 - multiplication");
			System.out.println("4 - division");
			System.out.println("0 - Exit");
			System.out.println("Please, enter number of menu to choice your operation:");
			Scanner scanner = new Scanner(System.in);
			String actionStr = scanner.next();			
			while(!Utils.isInt(actionStr)){
				System.out.println("Please, enter a correct number of menu to choice your operation:");
				actionStr = scanner.next();
			}
			int action=Integer.parseInt(actionStr);;
			switch (action) {
			case 0:
				isRepeat = false;
				System.out.println("Completed");
				break;

			case 1:
			case 2:
			case 3:
				String x;
				String y;
				System.out.println("Please, enter frist number: ");
				x=scanner.next();
				while(!Utils.isDouble(x)){
					System.out.println("Please, enter a correct number: ");
					x=scanner.next();
				}
				System.out.println("Please, enter second number: ");
				y=scanner.next();
				while(!Utils.isDouble(y)){
					System.out.println("Please, enter a correct number: ");
					y=scanner.next();
				}
				if(action==1){
					System.out.println("result is:"+x+"+"+y+"="+Calculation.addition(Double.parseDouble(x), Double.parseDouble(y)));	
				}
				else if(action==2){
					System.out.println("result is:"+x+"-"+y+"="+Calculation.substraction(Double.parseDouble(x), Double.parseDouble(y)));	
				}else if(action==3){
					System.out.println("result is:"+x+"*"+y+"="+Calculation.multiplication(Double.parseDouble(x), Double.parseDouble(y)));	
				}
						
				break;

			case 4:			
				System.out.println("Please, enter frist number: ");
				x=scanner.next();
				while(!Utils.isDouble(x)){
					System.out.println("Please, enter a correct number: ");
					x=scanner.next();
				}
				System.out.println("Please, enter second number: ");
				y=scanner.next();
				while(!Utils.isDouble(y)||Double.parseDouble(y)==0){
					System.out.println("Please, enter a correct number: ");
					y=scanner.next();
				}				
				System.out.println("result is:"+x+"/"+y+"="+Calculation.division(Double.parseDouble(x), Double.parseDouble(y)));	
				break;

			default:
				System.out.println("Incorrect value! Please, try again.");
				break;
			}
		}
	}

}
