package com.epam.ta.ivan;
/*
 * Calculation
 * author:Ivan_Fan@epam.com
 * 2015-12-30
 * */
public class Calculation {
   
	public static double addition(double x,double y){		
		return x+y;
	}
	public static double substraction(double x ,double y ){
		
		return x-y;
	}
	public static double multiplication(double x ,double y){
		
		return x*y;
	}
	public static double division(double x ,double y)  throws ArithmeticException{		 
		return x/y;
	}
}
