package com.epam.ta.ivan;

import java.util.Random;

/*
 * MatrixRunner
 * author:Ivan_Fan@epam.com
 * 2015-12-30
 * */
public class MatrixRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please, enter number for 'X':");
		int x=Utils.inputNumber("X");
		System.out.println("Please, enter number for 'Y':");	 
		int y=Utils.inputNumber("Y");
		int [][] arr=new int[x][y];		 
		Random random = new Random();
		for(int i=0;i<x;i++){
			for(int j=0;j<y;j++){
				arr[i][j]=random.nextInt(100); 
			}
			 
		}
		System.out.println("origin array:");
		for(int i=0;i<x;i++){
			for(int j=0;j<y;j++){
				System.out.print(arr[i][j]+" ");
			}
			System.out.println("");
		}
		
		System.out.println("matrix array:");
		for(int i=0;i<y;i++){
			for(int j=0;j<x;j++){
				System.out.print(arr[j][i]+" ");
			}
			System.out.println("");
		}
	}

}
