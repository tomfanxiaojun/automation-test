package com.epam.patterns.strategy;

public interface PaymentStrategy {
	void doPayment();
}
