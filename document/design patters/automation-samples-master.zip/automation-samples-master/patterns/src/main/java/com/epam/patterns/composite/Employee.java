package com.epam.patterns.composite;

public interface Employee {
	void showHappiness();
}
