package com.epam.na.mentoring.exceptions;

/**
 * Created by Vitali_Shulha on 01-Dec-15.
 */
public class NoPlanesException extends RuntimeException {



}
