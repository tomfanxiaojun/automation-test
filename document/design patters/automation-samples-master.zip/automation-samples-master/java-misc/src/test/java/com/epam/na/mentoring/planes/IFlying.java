package com.epam.na.mentoring.planes;

/**
 * Created by Vitali_Shulha on 01-Dec-15.
 */
public interface IFlying {

    void fly();

    Integer getTonnage();
}
