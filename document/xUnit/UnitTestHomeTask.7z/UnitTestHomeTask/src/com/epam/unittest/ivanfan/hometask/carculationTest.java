package com.epam.unittest.ivanfan.hometask;

import org.testng.annotations.*;
import org.testng.Assert;
import com.epam.ta.ivan.Calculation;

public class carculationTest {
	@BeforeClass
	public void beforeClass() {
		System.out.println("this is before class");
	}

	@Test(description = "right case for addition", groups = { "common" })
	public void TestAdditionTestCase01() {
		Assert.assertEquals(3.0, Calculation.addition(1, 2));

	}

	@Test(description = "wrong case for addition", groups = { "common" })
	public void TestAdditionTestCase02() {
		Assert.assertNotEquals(4.0, Calculation.addition(1, 2));

	}

	@Test(description = "right case for substraction", groups = { "common" })
	public void TestSubstractionTestCase01() {
		Assert.assertEquals(-1.0, Calculation.substraction(1, 2));

	}

	@Test(description = "wrong case for substraction", groups = { "common" })
	public void TestSubstractionTestCase02() {
		Assert.assertNotEquals(-2, Calculation.substraction(1, 2));

	}

	@Test(description = "right case for multiplication", groups = { "common" })
	public void TestMultiplicationTestCase01() {
		Assert.assertEquals(2.0, Calculation.multiplication(1, 2));

	}

	@Test(description = "right case for multiplication", groups = { "common" })
	public void TestMultiplicationTestCase02() {
		Assert.assertEquals(0.0, Calculation.multiplication(0, 2));

	}

	@Test(description = "wrong case for multiplication", groups = { "common" })
	public void TestMultiplicationTestCase03() {
		Assert.assertNotEquals(-2.0, Calculation.multiplication(1, 2));

	}

	@Test(description = "right case for multiplication", groups = { "common" })
	public void TestDivisionTestCase01() {
		Assert.assertEquals(0.5, Calculation.division(1, 2));

	}

	@Test(description = "right case for division", groups = { "special" })
	public void TestDivisionTestCase02() {
		Assert.assertEquals(0.0, Calculation.division(0, 2));

	}

	@Test(description = "wrong case for division", groups = { "special" })
	public void TestDivisionTestCase03() {
		Assert.assertNotEquals(-2.0, Calculation.division(1, 2));

	}

	@Test(description = "throw expection case for division", groups = { "special" }, expectedExceptions = ArithmeticException.class)
	public void TestDivisionTestCase04() {
		try {
			System.out.println(Calculation.division(1, 0));
		} catch (Exception e) {
			throw new ArithmeticException("error");
		}

	}

	@DataProvider(name = "parameters")
	public Object[][] Parameters() {
		return new Object[][] { { 1.0,1.0,2.0 },
				{ 2.0,5.0,7.0}, { 1.2,3.5,4.7} };
	}

	@Test(description = "verify addition by data provider",dataProvider = "parameters", groups = { "dataprovider" })
	public void TestAdditionTestCase04(Double x, Double y,Double result) {		 
		Assert.assertEquals(result, Calculation.addition(x, y));
	}

	@AfterClass
	public void afterClass() {
		System.out.println("this is after class");
	}
}
