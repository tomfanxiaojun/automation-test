package com.epam.cdp.cnta2016.module4.lecture3.samples.enums.simpleenum;

public enum Cars {
	LAMBORGHINI, TATA, AUDI, FIAT, HONDA;
}


